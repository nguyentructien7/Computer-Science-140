/*
 * Homework 2
 * author: Tien Nguyen
 * date: September-11-2015
 * description: The assignment is about solving math problems, telling knock-knock joke, and listing favorite books.
 */
package homework2;

public class Homework2 {

    public static void main(String[] args) {

        System.out.println( "Part one: variable values" );
        
        //change the values of a and b, so that the output equals 27
        int a = 0;   
        int b = 0;  
        System.out.println( 10 * 2 - 70 / 10 + ( 4 * 2 ) / 2 + 12 - 6 % 4 );
        
        System.out.println();
        System.out.println( "Part two: order of operations" );
        
        //add a single pair of parentheses in the right place to make the output equal to 7
        System.out.println( 6 % (1 * 10) - 4 + 4 * 3 / 5 - 3 % 7 + 6 );
        
        System.out.println();
        System.out.println( "Part three: a knock-knock joke" );
        
        //tell me a knock-knock joke (make it a good one)
        System.out.println( " - Knock knock" );
        System.out.println( " - Who's there?" );
        System.out.println(" - yah");
        System.out.println(" - yah who?");
        System.out.println(" - naaah, I perfer google");
        //add the rest of the joke
        
        System.out.println();
        System.out.println( "Part four: books" );
        System.out.println(" \"The Earthsea Cycle\" by Ursula Le Guin ");
        System.out.println(" \"The Realm of the Elderlings\" by Robin Hobb");
       
              
        //I am starved for a good book, so recommend your two (or more) favorites
        
    }   
    
    double z= (double)5/2+(-2*2)+2%6;
    
}