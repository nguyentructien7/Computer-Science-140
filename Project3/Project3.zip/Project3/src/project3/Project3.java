/*
 * Project 3
 * author: Tien Nguyen
 * date: October-27-2015
 * description: This assigment is about reading from a text file, looping, selection, running totals and methods.
 */
package project3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Project3 {

    //DO NOT ADD GLOBAL VARIABLES
    //DO NOT ALTER THIS METHOD
    public static void main(String[] args) {
        printResults("amg_competition.txt");
    }

    /* printResults - count contracts, compare and make a decision on the winner 
     * input: String fileName - input file name
     * return: nothing
     */
    //DO NOT ALTER THIS METHOD
    private static void printResults(String fileName) {
        int contactsBeggars = countContracts(fileName, "Beggars");

        int contactsSeamstresses = countContracts(fileName, "Seamstresses");
        int contactsThieves = countContracts(fileName, "Thieves");
        int contactsAssassins = countContracts(fileName, "Assassins");

        String winner = findWinner("Seamstresses", contactsSeamstresses, "Assassins", contactsAssassins, "Beggars", contactsBeggars, "Thieves", contactsThieves);

    }

    /* countContracts - read the input file looking for the guild name and print the breakdown 
     *                  of number of contracts by month with the total, and the total value of completed contracts
     * input: String fileName - input file name
     *        String guild - the name of the guild to look for
     * return: int - the total number of contracts fot the guild for the three months 
     */
    private static int countContracts(String fileName, String guild) {

        Scanner stream = null;

        //open the input file
        try {
            stream = new Scanner(new File(fileName));
        } catch (FileNotFoundException e) {
            System.out.println("File doesn't exist or not in project folder");
            System.exit(-1);
        }
        //DO NOT ALTER CODE IN THIS METHOD ABOVE THIS LINE
        //Declared new varibles
        int total = 0;
        int monthTotal = 0;
        String input;
        //IMPLEMENT THE REST OF THE METHOD HERE
        // In month 2 print out month 1 & in month 3 print out month 2.
        //Count the contracts in each months
        System.out.println(guild);

        while (stream.hasNext()) {
            input = stream.nextLine();

            if (guild.equals(input)) {
                total++;
                monthTotal++;

            } else if ("2".equals(input)) {
                System.out.println("Month 1:  " + monthTotal + "  contracts");
                monthTotal = 0;
            } else if ("3".equals(input)) {
                System.out.println("Month 2:  " + monthTotal + "  contracts");
                monthTotal = 0;
            }
        }
        System.out.println("Month 3:  " + monthTotal + "  contracts");
        //printf

        System.out.printf("Total:    %d ($%.2f) \n ", total, calculateContractTotal(total, guild));
        System.out.println();

        //REPLACE 0 WITH YOUR VALUE
        return total;

    }


    /* calculateContractTotal - calculate the total price of contracts for the three months
     * input: int totalContracts - the total number of contracts for the guild
     *        String guild - the name of the guild
     * return: double - the total value of contracts for this guild and this number of contracts
     */
    private static double calculateContractTotal(int totalContracts, String guild) {
        double money = 0;
        //IMPLEMENT THE REST OF THE METHOD HERE
        //Multiply the price per contract for each guilds
        switch (guild) {
            case ("Beggars"):
                money = totalContracts * 7.50;
                break;
            case ("Seamstresses"):
                money = totalContracts * 12;
                break;
            case ("Thieves"):
                money = totalContracts * 25;
                break;
            case ("Assassins"):
                money = totalContracts * 60;

                break;
            default:
                ;

        }

        //REPLACE 0 WITH YOUR VALUE
        return money;
    }

    /* makeDecision - finds the guild that had the most total value of contracts for the three months
     *                if two or more guilds grossed the same amount of money, pick the one with the 
     *                most individual contracts
     * input: String guild1       - name of the first guild to compare
     *        int contractsGuild1 - total price of contracts of guild1
     *        String guild2       - name of the first guild to compare
     *        int contractsGuild2 - total price of contracts of guild2
     *        String guild3       - name of the first guild to compare
     *        int contractsGuild3 - total number of contracts of guild3
     *        String guild4       - name of the first guild to compare
     *        int contractsGuild4 - total price of contracts of guild4
     * return: String - name of the guild that wins the competition
     */
    private static String findWinner(String guild1, int contractsGuild1, String guild2, int contractsGuild2,
            String guild3, int contractsGuild3, String guild4, int contractsGuild4) {
        //IMPLEMENT THE REST OF THE METHOD HERE

        //Declared new variables 
        double sTotal = 0;
        double bTotal = 0;
        double aTotal = 0;
        double tTotal = 0;
        double maxValue = 0;
        String winner = "";

        double revenue = 0;

        //Place holder for the money
        sTotal = calculateContractTotal(contractsGuild1, guild1);
        aTotal = calculateContractTotal(contractsGuild2, guild2);
        bTotal = calculateContractTotal(contractsGuild3, guild3);
        tTotal = calculateContractTotal(contractsGuild4, guild4);
        //set the 1st guild to the highest
        maxValue = sTotal;
        winner = guild1;

        //Compared each guilds money
        if (aTotal >= maxValue) {
            maxValue = aTotal;
            winner = guild2;
        }
        if (bTotal >= maxValue) {
            maxValue = bTotal;
            winner = guild3;
        }
        if (tTotal >= maxValue) {
            maxValue = tTotal;
            winner = guild4;
        }
        //if the guilds have the same amount of money
        //compared the number of contracts
        if (winner.equals(guild2)) {
            if (aTotal == sTotal) {
                if (contractsGuild1 > contractsGuild2) {
                    winner = guild1;
                }
            }
        }
        if (winner.equals(guild3)) {
            if (bTotal == aTotal) {
                if (contractsGuild2 > contractsGuild3) {
                    winner = guild2;
                }
            }
            if (bTotal == sTotal) {
                if (contractsGuild1 > contractsGuild3) {
                    winner = guild1;
                }
            }
        }
        if (winner.equals(guild4)) {
            if (tTotal == aTotal) {

            }
            if (contractsGuild1 > contractsGuild4) {
                winner = guild1;
            }
            if (tTotal == bTotal) {

            }
            if (contractsGuild3 > contractsGuild4) {
                winner = guild3;
            }
            if (tTotal == sTotal) {

            }
            if (contractsGuild4 > contractsGuild1) {
                winner = guild4;
            }

        }

        // The winner total amount of money multiplied by 4 for a year
        revenue = maxValue * 4;

        System.out.printf("With projected annual revenue of $%.2f the guild competition winner is the Guild of %s ", revenue, winner);

        return winner;

    }

}
